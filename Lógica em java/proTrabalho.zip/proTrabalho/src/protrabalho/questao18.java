/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String preco_str = "";
        String acrescimo_str = "";
        float acrescimoFinal = 0;
        float precoFinal = 0;
        
        preco_str = JOptionPane.showInputDialog(null,"informe o preço de custo do produto:");
        float preco = Float.parseFloat(preco_str);
        
        acrescimo_str = JOptionPane.showInputDialog(null,"informe o percentual de acrescimo:");
        float acrescimo = Float.parseFloat(acrescimo_str);
        
        acrescimoFinal = acrescimo / 100;
        precoFinal = preco + (preco * acrescimoFinal);
        
        JOptionPane.showMessageDialog(null,"valor da venda " + precoFinal);
    }
    
}
