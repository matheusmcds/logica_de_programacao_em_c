/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class questao1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String valor1_str = "";
        String valor2_str = "";
        String valor3_str = "";
        int produto = 0;
        float divisao = 0;
        
        valor1_str = JOptionPane.showInputDialog(null,"informe o valor 1:");
        int valor1 = Integer.parseInt(valor1_str);
        
        valor2_str = JOptionPane.showInputDialog(null,"informe o valor 2:");
        int valor2 = Integer.parseInt(valor2_str);
        
        valor3_str = JOptionPane.showInputDialog(null,"informe o valor 3:");
        int valor3 = Integer.parseInt(valor3_str);
        
        produto = valor1 * valor2 * valor3;
        divisao = (float)valor1 / valor2;
        
        JOptionPane.showMessageDialog(null,"o resultado do produto é " +produto);
        JOptionPane.showMessageDialog(null,"o resultado da divisão é " +divisao);
                
                
        
        
    }
    
}
