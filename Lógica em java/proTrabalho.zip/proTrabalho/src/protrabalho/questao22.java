/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String nome = "";
         String idade_str = "";
         int dias = 0;
         
        nome= JOptionPane.showInputDialog(null,"informeseu nome:");
        
        idade_str = JOptionPane.showInputDialog(null,"informe sua idade:");
        int idade = Integer.parseInt(idade_str);
        
        dias = idade * 365;
        
        JOptionPane.showMessageDialog(null,nome+ " você ja viveu " + dias + " dias");
        
        
    }
    
}
