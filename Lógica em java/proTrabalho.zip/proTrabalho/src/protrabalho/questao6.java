/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class questao6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nome = "";
        String altura_str = "";
        float conversao = 0;
        
        nome = JOptionPane.showInputDialog(null,"informe o seu nome: ");
        
        altura_str = JOptionPane.showInputDialog(null,"informe sua altura em centimetros");
        float altura = Float.parseFloat(altura_str);
        
        conversao = altura / 100;
        
        JOptionPane.showMessageDialog(null,"Nome: " +nome);
        JOptionPane.showMessageDialog(null,"a sua altura é " +conversao+ "metros");
    }
    
}
