/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String camisetaPQN_str = "";
        String camisetaMED_str = "";
        String camisetaGRD_str = "";
        int venda = 0;
        
        
        camisetaPQN_str = JOptionPane.showInputDialog(null,"informe a quantidade de camisetas pequenas:");
        int camisetaPQN = Integer.parseInt(camisetaPQN_str);
        
        camisetaMED_str = JOptionPane.showInputDialog(null,"informe a quantidade de camisetas medias:");
        int camisetaMED = Integer.parseInt(camisetaMED_str);
        
        camisetaGRD_str = JOptionPane.showInputDialog(null,"informe a quantidade de camisetas grandes:");
        int  camisetaGRD = Integer.parseInt( camisetaGRD_str);
        
        venda = (camisetaPQN * 10) + (camisetaMED * 12) + (camisetaGRD * 15);
        
        JOptionPane.showMessageDialog(null,"valor total: " +venda);
        
    }
    
}
