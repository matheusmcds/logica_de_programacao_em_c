/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class questao4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String valor1_str = "";
        String valor2_str = "";
        String valor3_str = "";
        float media = 0;
        
        valor1_str = JOptionPane.showInputDialog(null,"informe o valor 1:");
        float valor1 = Float.parseFloat(valor1_str);
        
        valor2_str = JOptionPane.showInputDialog(null,"informe o valor 2:");
        float valor2 = Float.parseFloat(valor2_str);
        
        valor3_str = JOptionPane.showInputDialog(null,"informe o valor 3:");
        float valor3 = Float.parseFloat(valor3_str);
        
        media = (valor1 + valor2 + valor3)/3;
        
        JOptionPane.showMessageDialog(null,"o rsultado da media é " +media);
    }
    
}
