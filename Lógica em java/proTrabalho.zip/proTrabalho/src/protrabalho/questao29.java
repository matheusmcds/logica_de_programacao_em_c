/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String baseMaior_str = "";
        String baseMenor_str = "";
        String altura_str = "";
        float area = 0;
        
        baseMaior_str = JOptionPane.showInputDialog(null,"informe o tamanho da base maior:");
        float baseMaior = Float.parseFloat(baseMaior_str);
        
        baseMenor_str = JOptionPane.showInputDialog(null,"informe o tamanho da base menor:");
        float baseMenor = Float.parseFloat(baseMenor_str);
        
        altura_str = JOptionPane.showInputDialog(null,"informe a altura:");
        float altura = Float.parseFloat(altura_str);
        
        area = (baseMaior + baseMenor)* altura/2;
        
        JOptionPane.showMessageDialog(null,"área: " + area);
    }
    
}
