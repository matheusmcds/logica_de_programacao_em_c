/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String prato_str = "";
        float total = 0;
        
        
        prato_str = JOptionPane.showInputDialog(null,"informe o peso do prato:");
        float prato = Float.parseFloat(prato_str);
        
        total = prato * 12.00f;
        
        JOptionPane.showMessageDialog(null,"total a pagar: " + total);
    }
    
}
