/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nome = "";
        String salarioFixo_str = "";
        String vendas_str = "";
        float salarioFinal = 0;
        
        nome = JOptionPane.showInputDialog(null,"informe seu nome: ");
        
        salarioFixo_str = JOptionPane.showInputDialog(null,"informe seu salario fixo: ");
        float  salarioFixo = Float.parseFloat(salarioFixo_str);
        
        vendas_str = JOptionPane.showInputDialog(null,"informe suas vendas:");
        float vendas = Float.parseFloat(vendas_str);
        
        salarioFinal =  salarioFixo + (vendas * 0.15f);
        
        JOptionPane.showMessageDialog(null,"funcionario: " +nome);
        JOptionPane.showMessageDialog(null,"salario fixo: " +salarioFixo);
        JOptionPane.showMessageDialog(null,"salario final: " +salarioFinal);
        
    }
    
}
