/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String dia_str = "";
        String mes_str = "";
        int diasAtuais = 0;
        
        dia_str = JOptionPane.showInputDialog(null,"informe o dia:");
        int dia= Integer.parseInt(dia_str);
        
        mes_str = JOptionPane.showInputDialog(null,"informe o mes:");
        int mes = Integer.parseInt(mes_str);
        
        diasAtuais = (mes - 1) * 30 + dia;
        
        JOptionPane.showMessageDialog(null,"dias passados: " + diasAtuais);
        
    }
    
}
