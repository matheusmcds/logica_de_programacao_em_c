/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String salarioFixo_str = "";
        String vendas_str = "";
        float comissao = 0;
        float salarioFinal = 0;
        
        
        salarioFixo_str= JOptionPane.showInputDialog(null,"informe o salario fixo :");
        float salarioFixo = Float.parseFloat(salarioFixo_str);
        
        vendas_str= JOptionPane.showInputDialog(null,"informe o valor das vendas:");
        float vendas = Float.parseFloat(vendas_str);
        
        comissao = vendas * 0.04f;
        salarioFinal = salarioFixo + comissao;
        
        JOptionPane.showMessageDialog(null,"valor de comissão " + comissao);
        JOptionPane.showMessageDialog(null,"salario final " + salarioFinal);

    }
    
}
