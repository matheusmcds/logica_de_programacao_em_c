/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String base_str = "";
         String altura_str = "";
         float terreno = 0;
        
        base_str = JOptionPane.showInputDialog(null,"informe o tamanho da base do terreno:");
        float base = Float.parseFloat( base_str);
        
        altura_str = JOptionPane.showInputDialog(null,"informe a altura do terreno:");
        float altura = Float.parseFloat(altura_str);
        
        terreno = base * altura;
        
        JOptionPane.showMessageDialog(null,"área total do terreno: " + terreno);
    }
    
}
