/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String dolar_str = "";
        String cotacaoDolar_str = "";
        float reais = 0;
        
        
        dolar_str = JOptionPane.showInputDialog(null,"informe os dolares: ");
        float dolar = Float.parseFloat(dolar_str);
        
        cotacaoDolar_str = JOptionPane.showInputDialog(null,"informe a cotação do dolar:");
        float cotacaoDolar = Float.parseFloat(cotacaoDolar_str);
        
        reais =  dolar * cotacaoDolar;
        
        JOptionPane.showMessageDialog(null,"o valor da conversão é  " +reais);
       
    }
    
}
