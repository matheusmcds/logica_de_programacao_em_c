/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String pagamento_str = "";
        String valorGasolina_str = "";
        float abastecimento = 0;
        
        
        pagamento_str = JOptionPane.showInputDialog(null,"informe o valor do abastecimento:");
        float pagamento = Float.parseFloat(pagamento_str);
        
        valorGasolina_str= JOptionPane.showInputDialog(null,"informe o valor da gasolina:");
        float valorGasolina = Float.parseFloat(valorGasolina_str);
        
        abastecimento = pagamento * valorGasolina;
        
        JOptionPane.showMessageDialog(null,"litros abastecidos: " + abastecimento);
    }
    
}
