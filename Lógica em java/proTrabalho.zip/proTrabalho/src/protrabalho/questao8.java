/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String anos_str = "";
        String meses_str = "";
        String dias_str = "";
        int idade = 0;
        
        anos_str = JOptionPane.showInputDialog(null,"informe sua idade em anos:");
        int anos = Integer.parseInt(anos_str);
        
        meses_str = JOptionPane.showInputDialog(null,"informe sua idade em meses:");
        int meses = Integer.parseInt(meses_str);
        
        dias_str = JOptionPane.showInputDialog(null,"informe sua idade em dias:");
        int dias = Integer.parseInt(dias_str);
        
        idade = anos * 365 + meses * 30 + dias;
        
        JOptionPane.showMessageDialog(null,"sua idade em dias é " +idade);
    }
    
}
