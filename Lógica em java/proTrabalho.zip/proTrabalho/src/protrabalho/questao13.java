/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String distancia_str = "";
        String gastoCombustivel_str = "";
        float consumo = 0;
        
        distancia_str = JOptionPane.showInputDialog(null,"informe a distancia percorrida: ");
        float  distancia = Float.parseFloat(distancia_str);
        
        gastoCombustivel_str = JOptionPane.showInputDialog(null,"informe o consumo de combustivel:");
        float gastoCombustivel = Float.parseFloat(gastoCombustivel_str);
        
        consumo = distancia / gastoCombustivel;
        
        JOptionPane.showMessageDialog(null,"o consumo médio de combustivel é " +consumo);
    }
    
}
