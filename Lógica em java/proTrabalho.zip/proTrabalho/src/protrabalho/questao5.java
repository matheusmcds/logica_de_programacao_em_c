/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class questao5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String valor1_str = "";
         String valor2_str = "";
         float soma = 0;
         float subtracao = 0;
         float produto = 0;
         float divisao = 0;
         float resto = 0;
         
        valor1_str = JOptionPane.showInputDialog(null,"informe o valor 1:");
        float valor1 = Float.parseFloat(valor1_str);
        
        valor2_str = JOptionPane.showInputDialog(null,"informe o valor 2:");
        float valor2 = Float.parseFloat(valor2_str);
        
        soma = valor1 + valor2;
        subtracao = valor1 - valor2;
        produto = valor1 * valor2;
        divisao = valor1 / valor2;
        resto = valor1 % valor2;
        
        JOptionPane.showMessageDialog(null,"o rsultado da soma é " +soma);
        JOptionPane.showMessageDialog(null,"o rsultado da subtração é " +subtracao);
        JOptionPane.showMessageDialog(null,"o rsultado do produto é " +produto);
        JOptionPane.showMessageDialog(null,"o rsultado da divisão é " +divisao);
        JOptionPane.showMessageDialog(null,"o resto da divisão é " +resto);
    }
    
}
