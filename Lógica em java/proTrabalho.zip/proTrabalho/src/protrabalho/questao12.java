/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String custoFabrica_str = "";
       float custoFinal = 0;
       
       custoFabrica_str = JOptionPane.showInputDialog(null,"informe o custo de fabrica do carro: ");
        float custoFabrica = Float.parseFloat(custoFabrica_str);
        
        custoFinal = custoFabrica + (custoFabrica * 0.28f) + (custoFabrica * 0.45f);
       
         JOptionPane.showMessageDialog(null,"o custo final do carro é " +custoFinal);
    }
    
}
