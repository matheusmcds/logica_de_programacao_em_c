/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String segundos_str = "";
        int horas = 0;
        int minutos = 0;
        int segundosRest = 0;
        
        segundos_str = JOptionPane.showInputDialog(null,"informe os segundos:");
        int segundos = Integer.parseInt(segundos_str);
        
        horas = ((segundos/60)/60);
        minutos = ((segundos/60)%60);
        segundosRest = segundos %60;
        
        JOptionPane.showMessageDialog(null,"os segundos expressos em horas são: " + horas);
        JOptionPane.showMessageDialog(null,"em minutos são: " + minutos);
        JOptionPane.showMessageDialog(null,"e em segundos : " + segundosRest);
    }
    
}
