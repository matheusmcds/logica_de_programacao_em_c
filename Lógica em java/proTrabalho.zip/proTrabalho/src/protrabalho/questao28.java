/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String salario_str = "";
        float aumento = 0;
        float salarioFinal = 0;
        
        salario_str = JOptionPane.showInputDialog(null,"informe seu salario: ");
        float salario = Float.parseFloat(salario_str);
        
        aumento = salario + (salario * 0.15f);
        salarioFinal = aumento - (aumento * 0.08f);
        
        JOptionPane.showMessageDialog(null,"salario inicial " +salario);
        JOptionPane.showMessageDialog(null,"salario com aumento " +aumento);
        JOptionPane.showMessageDialog(null,"salario final " +salarioFinal);
    }
    
}
