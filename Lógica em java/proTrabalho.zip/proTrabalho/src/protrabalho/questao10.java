/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String valor1_str = "";
        String valor2_str = "";
        String valor3_str = "";
        float mediaPonderada = 0;
        
        valor1_str = JOptionPane.showInputDialog(null,"informe o valor 1:");
        int valor1 = Integer.parseInt(valor1_str);
        
        valor2_str = JOptionPane.showInputDialog(null,"informe o valor 2:");
        int valor2 = Integer.parseInt(valor2_str);
        
        valor3_str = JOptionPane.showInputDialog(null,"informe o valor 3:");
        int valor3 = Integer.parseInt(valor3_str);
        
        mediaPonderada = (valor1 * 2 + valor2 * 3 + valor3 * 5) / 2 + 3 + 5;
        
        JOptionPane.showMessageDialog(null,"o resultado final é " +mediaPonderada);
        
    }
    
}
