/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class questao21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String pao_str = "";
         String broa_str = "";
         float totalPaes = 0;
         float totalBroas = 0;
         float totalVenda = 0;
         float poupanca = 0;
         
        pao_str = JOptionPane.showInputDialog(null,"informe quantidade de pães vendidos:");
        int pao = Integer.parseInt(pao_str);
        
        broa_str = JOptionPane.showInputDialog(null,"informe a quantidade de broas vendidas:");
        int broa = Integer.parseInt(broa_str);
        
        totalPaes = (float) pao * 0.12f;
        totalBroas = (float)broa * 1.50f;
        totalVenda = totalPaes + totalBroas;
        poupanca = totalVenda * 0.10f;
        
        JOptionPane.showMessageDialog(null,"total da venda " +totalVenda);
        JOptionPane.showMessageDialog(null,"valor a ser depositado " +poupanca);
        
    }
    
}
