/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalho;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class questao3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String valor1_str = "";
        String valor2_str = "";
        int valor3 = 0;
        
        valor1_str = JOptionPane.showInputDialog(null,"informe o valor 1:");
        int valor1 = Integer.parseInt(valor1_str);
        
        valor2_str = JOptionPane.showInputDialog(null,"informe o valor 2:");
        int valor2 = Integer.parseInt(valor2_str);
        
        valor3 = valor1;
        valor1 = valor2;
        valor2 = valor3;
        
        JOptionPane.showMessageDialog(null,"o valor 1 é " + valor1 + " o valor 2 é " +valor2);
        
    }
    
}
