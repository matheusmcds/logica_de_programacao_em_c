/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor;
        int cont;
        int negativos = 0;
        vetor = new int [10];
        
        for(cont = 0; cont < vetor.length ; cont++){
          vetor[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um valor: ")); 
        }
        
        for(cont = 0; cont < vetor.length ; cont++){
         if(vetor[cont] < 0 ){
             negativos++;
         }
        }
        
         JOptionPane.showMessageDialog(null,"A quantidade de negativos é: " +negativos);
    }
    
}
