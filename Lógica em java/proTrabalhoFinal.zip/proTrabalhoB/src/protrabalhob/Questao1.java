/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String [] sexo;
        String [] resposta;
        int cont;
        int homemS = 0;
        int mulherS = 0;
        int totalHomem = 0;
        int totalMulher = 0;
        float porcentagemH;
        float porcentagemM;
        
        resposta = new String [20];
        sexo = new String [20];
        
        for(cont = 0 ; cont < 20 ; cont++){
            
        sexo[cont] = (JOptionPane.showInputDialog(null, "qual seu sexo? 'm' para mulher ou 'h' para homem "));
            
        resposta[cont]= (JOptionPane.showInputDialog(null, "Você gostou do produto? 's' para sim ou 'n' para não "));
        }
        
        for(cont = 0 ; cont < 20 ; cont++){
            if(sexo[cont].equalsIgnoreCase("m")){
                totalMulher++;
                if(resposta[cont].equalsIgnoreCase("s")){
                    mulherS++;
                }
            }
            
             if(sexo[cont].equalsIgnoreCase("h")){
                 totalHomem++;
                if(resposta[cont].equalsIgnoreCase("s")){
                    homemS++;
                }
            }
        }
        
        porcentagemH = ((float)homemS * 100) / totalHomem;
        porcentagemM = ((float)mulherS * 100) / totalMulher;
        
       JOptionPane.showMessageDialog(null,"porcentagem de homens que gostaram: " + porcentagemH + "%");
       JOptionPane.showMessageDialog(null,"porcentagem de mulheres que gostaram:" +porcentagemM + "%");
        
        
    }
    
}
