/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class Questao13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int [] vetor;
       int cont;
       
       
       vetor = new int [10];
       
       for(cont = 0 ; cont < vetor.length ; cont++){
           vetor[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um valor: "));
       }
       
       for(cont = 9 ; cont >= 0 ; cont--){
           JOptionPane.showMessageDialog(null,"vetor ao contrario " + cont+"=" + vetor[cont]);
       }
    }
    
}
