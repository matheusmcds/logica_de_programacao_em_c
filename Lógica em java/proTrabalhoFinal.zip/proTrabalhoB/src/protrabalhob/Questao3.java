/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String [] estadoCivil;
        int casadas = 0;
        int cont;
        
        estadoCivil = new String [15];
        
        for(cont = 0 ; cont <  estadoCivil.length ; cont++ ){
            estadoCivil[cont] = (JOptionPane.showInputDialog(null, "qual o seu estado civil? informe 'c' para casada ou 's' para solteira "));
            
        }
        
        for(cont = 0 ; cont <  estadoCivil.length ; cont++ ){
            if(estadoCivil[cont].equalsIgnoreCase("c")){
                casadas++;
            }
        }
        JOptionPane.showMessageDialog(null,"A quantidade de pessoas casadas é:  "+casadas);
    }
    
}
