/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class Questao17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vetorx;
        int cont;
        int numero;
        int qtdnumero = 0;

        vetorx = new int[10];

        numero = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um numero: "));

        for (cont = 0; cont < vetorx.length; cont++) {
            vetorx[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe os valores para o vetor x: "));
        }

        for (cont = 0; cont < vetorx.length; cont++) {
            if (vetorx[cont] == numero) {
                qtdnumero++;
            }
        }

        if (qtdnumero == 0) {
            JOptionPane.showMessageDialog(null, "Não existe o valor no vetor ");
        } else {
            JOptionPane.showMessageDialog(null, "A quantidade de vezes que o numero  " + numero + "aparece no vetor é: " + qtdnumero);
            for (cont = 0; cont < vetorx.length; cont++) {
                if (vetorx[cont] == numero) {
                    JOptionPane.showMessageDialog(null, "Posição " + cont + " = " + vetorx[cont]);
                }
            }
        }

    }

}
