/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor;
        int cont;
        int somaImpar = 0;
        int qtdImpar = 0;
        float media;
        vetor = new int[10];
        
        for(cont = 0; cont < vetor.length ; cont++){
          vetor[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um valor: "+cont)); 
          
         }
        
        for(cont = 0; cont < vetor.length ; cont++){
            if(vetor[cont] %2 != 0 ){
              somaImpar = somaImpar + vetor[cont];
              qtdImpar++;
            }         
        }
        media = (float)(somaImpar) / qtdImpar;
        
        JOptionPane.showMessageDialog(null,"A média do valores do vetor é  "+media);
    }   
}
