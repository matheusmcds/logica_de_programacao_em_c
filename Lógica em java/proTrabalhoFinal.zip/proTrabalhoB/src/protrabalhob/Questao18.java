/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class Questao18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vetor;
        int cont;
        int maiorValor = 0;

        vetor = new int[8];

        for (cont = 0; cont < vetor.length; cont++) {
            vetor[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe os valores para o vetor: "));
        }

        for (cont = 0; cont < vetor.length; cont++) {
            if (vetor[cont] > maiorValor) {
                maiorValor = vetor[cont];
            }
        }

        for (cont = 0; cont < vetor.length; cont++) {
            if (vetor[cont] == maiorValor) {
                JOptionPane.showMessageDialog(null, " Maior Posição " + cont + " = " + vetor[cont]);

            }

        }
    }
}
