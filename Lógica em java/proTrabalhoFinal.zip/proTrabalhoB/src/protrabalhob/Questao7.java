/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[]vetorA;
        int cont;
        int x = 5;
        int qtdX = 0;
        
        vetorA = new int [10];
        
        for(cont = 0; cont < vetorA.length; cont++){
            vetorA[cont] = Integer.parseInt(JOptionPane.showInputDialog(null,"informe um valor: "));
        }
        
        for(cont = 0; cont < vetorA.length; cont++){
            if(vetorA[cont] == x){
                qtdX++;
            }
        }
        
        JOptionPane.showMessageDialog(null,"a quantida de vezes que o valor x aparece é:" +qtdX);
    }
    
}
