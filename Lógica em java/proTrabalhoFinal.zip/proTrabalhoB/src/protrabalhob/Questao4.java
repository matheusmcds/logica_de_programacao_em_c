/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num;
        int cont;
        String [] palavra;
        
        num = Integer.parseInt (JOptionPane.showInputDialog(null, "Informe um valor: "));
        
        palavra = new String [num];
        
        for(cont = 0 ; cont < palavra.length ; cont++){
            palavra [cont] = "programa";
        }
        
         for(cont = 0 ; cont < palavra.length ; cont++){
             JOptionPane.showMessageDialog(null,"posição"+ cont +" = "+palavra[cont]);
         }
    }
    
}
