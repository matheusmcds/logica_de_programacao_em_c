/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class Questao14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vetorA;
        int[] vetorB;
        int[] vetorSoma;
        int cont;

        vetorA = new int[10];
        vetorB = new int[10];
        vetorSoma = new int[10];

        for (cont = 0; cont < vetorA.length; cont++) {
            vetorA[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe os valores para o vetor A: "));
        }

        for (cont = 0; cont < vetorB.length; cont++) {
            vetorB[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe os valores para o vetor B: "));
        }

        for (cont = 0; cont < vetorSoma.length; cont++) {
            vetorSoma[cont] = vetorA[cont] + vetorB[cont];
        }
        for (cont = 0; cont < vetorSoma.length; cont++) {
            JOptionPane.showMessageDialog(null, "Os resultados do vetor soma são: " + cont + "=" + vetorSoma[cont]);
        }
    }

}
