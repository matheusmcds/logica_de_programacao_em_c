/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author MatheusCostadaSilva
 */
public class Questao9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x;
        int cont;
        String [] palavra;
        
        x = Integer.parseInt (JOptionPane.showInputDialog(null, "Informe o numero de pessoas: "));
        
        palavra = new String [x];
        
        for( cont = 0; cont < x; cont ++){
            palavra[cont] = (JOptionPane.showInputDialog(null, "Informe seu nome completo: "));
        }
        for( cont = 0; cont < x; cont ++){
        JOptionPane.showMessageDialog(null,"nome: " +palavra[cont]);
        }
    }
    
}
