/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protrabalhob;

import javax.swing.JOptionPane;

/**
 *
 * @author T-GAMER
 */
public class Questao11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int []vetorInt;
        int []vet1;
        int cont;
        
        vetorInt = new int [5];
        vet1 = new int [5];
        
         for(cont = 0 ; cont < 5 ; cont++){
             vetorInt[cont] = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um valor: "));
         }
         
         for(cont = 0 ; cont < 5 ; cont++){
             vet1[cont] = vetorInt[cont];
         }
         
        for(cont = 0 ; cont < 5 ; cont++){
            JOptionPane.showMessageDialog(null,"vetor inteiros " + cont+"=" + vetorInt[cont]);
           
        }
        for(cont = 0 ; cont < 5 ; cont++){
            JOptionPane.showMessageDialog(null,"vet1 " + cont + "=" +  vet1[cont]);
        }
    }
    
}
